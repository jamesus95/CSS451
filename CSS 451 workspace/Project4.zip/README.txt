Double Click .exe file to run

w = forward
s = backward
a = turn left
d = turn right
q = strafe left
e = strafe right
left ctrl = down
space bar = up

All shaders are built into Unity and don't require any coding