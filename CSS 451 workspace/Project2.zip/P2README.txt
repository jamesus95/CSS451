Double click exe file to run!

I've added effects to the generated items (sphere, cube, pyramid) when they are clicked on.
In the final project UI there won't be a graphical part, but there will be some instructions either
that pop up at the beginning in a window, or that are written along the top or bottom of the screen.
All the controls will be the same in the final project.